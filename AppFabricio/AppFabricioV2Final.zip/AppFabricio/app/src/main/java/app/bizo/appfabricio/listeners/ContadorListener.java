package app.bizo.appfabricio.listeners;

import android.widget.Button;

public interface ContadorListener {
    void incrementar();
    void decrementar();
    void resolver(Button botao);
}
